
ALTER TABLE episodes 
ADD COLUMN date_is_approximate boolean DEFAULT false;
